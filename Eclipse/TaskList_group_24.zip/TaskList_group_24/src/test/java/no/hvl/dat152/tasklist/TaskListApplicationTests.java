package no.hvl.dat152.tasklist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskListApplicationTests {

	@Test
	void contextLoads() {
	}

}
